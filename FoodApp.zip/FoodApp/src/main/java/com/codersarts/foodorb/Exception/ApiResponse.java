package com.codersarts.foodorb.Exception;

import com.codersarts.foodorb.entity.foodCategory;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ApiResponse {

	String message;
	boolean status;
}
