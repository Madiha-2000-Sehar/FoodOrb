package com.codersarts.foodorb.controller;

import com.codersarts.foodorb.UI.*;
import com.codersarts.foodorb.services.checkoutService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.codersarts.foodorb.Dto.Purchase;

@RestController
@RequestMapping("/api/check-out")
@CrossOrigin("*")
public class checkoutController {

	@Autowired
	private checkoutService checkoutservice;
	
	
	@PostMapping("/")
	public ResponseEntity<String> placeOrder(@RequestBody Purchase purchase){
		
		purchaseResponse response=this.checkoutservice.placeOrder(purchase);
		return ResponseEntity.ok(response.getOrderTrackingNumber());
	}
}
