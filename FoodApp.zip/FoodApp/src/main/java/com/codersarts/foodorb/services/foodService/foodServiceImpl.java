package com.codersarts.foodorb.services.foodService;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.codersarts.foodorb.Dto.foodDto;
import com.codersarts.foodorb.dao.categoryRepo;
import com.codersarts.foodorb.dao.foodRepository;
import com.codersarts.foodorb.entity.Food;
import com.codersarts.foodorb.entity.foodCategory;
import com.codersarts.foodorb.Exception.ResourceNotFoundException;

@Service
public class foodServiceImpl implements foodService {

	
	@Autowired
	private foodRepository fRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private categoryRepo cRepo;
	
	
	@Override
	public boolean addFood(foodDto dto,Long categoryId) {
		foodCategory c=this.cRepo.findById(categoryId).orElseThrow(()-> new ResourceNotFoundException("category","categoryId",categoryId));
		
		Food food=this.modelMapper.map(dto, Food.class);
		food.setCategory(c);
		this.fRepo.save(food);
		return true;
	}

	@Override
	public List<foodDto> getAllFoods(Integer pageNumber,Integer pageSize) {
		Pageable p=PageRequest.of(pageNumber,pageSize);
		Page<Food> foodsPage=this.fRepo.findAll(p);
		List<Food> foods=foodsPage.getContent();
		List<foodDto> dtos=new ArrayList<>();
		for(Food f:foods) {
			dtos.add(this.modelMapper.map(f, foodDto.class));
		}
		return dtos;
	}

	@Override
	public List<foodDto> getFoodByCategory(Long id,Integer pageNumber,Integer pageSize) {
		
		
		Pageable p=PageRequest.of(pageNumber, pageSize);
		
		
		foodCategory fc=this.cRepo.findById(id).orElseThrow(()->new ResourceNotFoundException("category","categoryId",id));
		Page<Food> foodpage=this.fRepo.findByCategory(fc,p);
		List<Food> page=foodpage.getContent();
		List<foodDto> dtos=new ArrayList<>();
		for(Food f:page) {
		dtos.add(this.modelMapper.map(f, foodDto.class));
		}
		return dtos;
	}

	@Override
	public List<foodDto> search(String keyword) {
		
		Pageable p=PageRequest.of(0, 4);
		Page<Food> foodPage=this.fRepo.findByNameContaining(keyword, p);
		List<Food> pageContent=foodPage.getContent();
		List<foodDto> dtos=new ArrayList<>();
		for(Food f:pageContent) {
			dtos.add(this.modelMapper.map(f, foodDto.class));
		}
		return dtos;
	}

	@Override
	public foodDto getFoodById(Long id) {
		Food food=this.fRepo.findById(id).orElseThrow(()->new ResourceNotFoundException("Food","Id",id));
		return this.modelMapper.map(food, foodDto.class);
	}

}
