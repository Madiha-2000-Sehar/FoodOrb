package com.codersarts.foodorb.dao;


import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.codersarts.foodorb.entity.Food;
import com.codersarts.foodorb.entity.foodCategory;

public interface foodRepository extends JpaRepository<Food, Long>{

	 Page<Food> findByCategory(foodCategory fc,Pageable pageable);
	//the above statement gets transformed into 'select *from food where category_id=id'
	 
	 Page<Food> findByNameContaining(String Keyword,Pageable pageable);
}
