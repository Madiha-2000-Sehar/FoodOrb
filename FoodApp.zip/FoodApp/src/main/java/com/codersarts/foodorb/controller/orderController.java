package com.codersarts.foodorb.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.codersarts.foodorb.UI.orderResponse;
import com.codersarts.foodorb.entity.orders;
import com.codersarts.foodorb.services.orderService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.*;

@RestController
@RequestMapping("/foodorb/orders")
@CrossOrigin("*")
public class orderController {

	@Autowired
	private orderService orderservice;
	
	@GetMapping("/{email}")
	public ResponseEntity<List<orderResponse>> myOrders(@PathVariable String email){
		
		List<orderResponse> o=this.orderservice.myOrders(email);
		return ResponseEntity.ok(o);
	}
}
