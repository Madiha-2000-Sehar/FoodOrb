package com.codersarts.foodorb.services;

import java.util.List;

import com.codersarts.foodorb.UI.orderResponse;
import com.codersarts.foodorb.entity.orders;

public interface orderService {

	List<orderResponse> myOrders(String email);
}
