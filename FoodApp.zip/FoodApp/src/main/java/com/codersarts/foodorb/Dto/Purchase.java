package com.codersarts.foodorb.Dto;

import java.util.Set;

import com.codersarts.foodorb.entity.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Purchase {
	
	private Customer customer;
	
	private Address shippingAddress;
	
	private orders order;
	
	private Set<orderItem> items;

}
