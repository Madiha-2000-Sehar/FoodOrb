package com.codersarts.foodorb.services;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codersarts.foodorb.Dto.categoryDto;
import com.codersarts.foodorb.dao.categoryRepo;
import com.codersarts.foodorb.entity.foodCategory;


@Service
public class categoryServiceImpl implements categoryService {

	@Autowired
	private categoryRepo cRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	
	@Override
	public boolean addCategory(categoryDto dto) {
		
		foodCategory fc=this.modelMapper.map(dto, foodCategory.class);
		this.cRepo.save(fc);
		return true;
	}

	@Override
	public List<categoryDto> getAllCategories() {
		List<foodCategory> foods=this.cRepo.findAll();
		List<categoryDto> dtos=new ArrayList<>();
		for(foodCategory c:foods) {
			dtos.add(this.modelMapper.map(c, categoryDto.class));
		}
		return dtos;
	}

}
