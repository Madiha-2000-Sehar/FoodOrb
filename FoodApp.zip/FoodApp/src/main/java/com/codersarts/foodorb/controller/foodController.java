package com.codersarts.foodorb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.codersarts.foodorb.Dto.categoryDto;
import com.codersarts.foodorb.Dto.foodDto;
import com.codersarts.foodorb.Exception.ApiResponse;
import com.codersarts.foodorb.services.categoryService;
import com.codersarts.foodorb.services.foodService.foodService;

@RestController
@RequestMapping("/foodorb/food")
@CrossOrigin("*")
public class foodController {

	@Autowired
	private foodService fService;
	
	@PostMapping("/add-food/category/{id}")
	public ResponseEntity<ApiResponse> addFood(@RequestBody foodDto dto,@PathVariable Long id){
		
		boolean status=this.fService.addFood(dto,id);
		
		if(status)
			return new ResponseEntity(new ApiResponse("Food Added!",true), HttpStatus.CREATED);
		else
		return new ResponseEntity(new ApiResponse("Error Occured!!",false),HttpStatus.BAD_REQUEST);
		
	}
	
	@GetMapping("/")
	public ResponseEntity<List<foodDto>> getAllFoods(@RequestParam(value="pageNumber",defaultValue="0",required=false) Integer pageNumber,@RequestParam(value="pageSize",defaultValue="2",required=false) Integer pageSize){
		List<foodDto> dtos=this.fService.getAllFoods(pageNumber,pageSize);
		return ResponseEntity.ok(dtos) ;
		
	}
	
	@GetMapping("/search/c/{id}")
	public ResponseEntity<List<foodDto>> getFoodByCategory(@PathVariable Long id,@RequestParam(value="pageNumber",defaultValue="10",required=false) Integer pageNumber,@RequestParam(value="pageSize",defaultValue="2",required=false) Integer pageSize){
		
		List<foodDto> dtos=this.fService.getFoodByCategory(id,pageNumber,pageSize);
		return ResponseEntity.ok(dtos);
		
	}
	
	@GetMapping("/search/{keyword}")
	public ResponseEntity<List<foodDto>> searchByName(@PathVariable String keyword,@RequestParam(value="pageNumber",defaultValue="10",required=false) Integer pageNumber,@RequestParam(value="pageSize",defaultValue="2",required=false) Integer pageSize){
		
		List<foodDto> dtos=this.fService.search(keyword);
		return ResponseEntity.ok(dtos);
		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<foodDto> getFoodById(@PathVariable Long id,@RequestParam(value="pageNumber",defaultValue="10",required=false) Integer pageNumber,@RequestParam(value="pageSize",defaultValue="2",required=false) Integer pageSize){
		
		foodDto dto=this.fService.getFoodById(id);
		return ResponseEntity.ok(dto);
		
	}

}
