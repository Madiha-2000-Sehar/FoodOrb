package com.codersarts.foodorb.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codersarts.foodorb.entity.Address;
import com.codersarts.foodorb.entity.Food;

public interface addressRepo  extends JpaRepository<Address, Integer>{

}
