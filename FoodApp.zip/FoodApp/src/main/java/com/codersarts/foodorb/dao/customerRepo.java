package com.codersarts.foodorb.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codersarts.foodorb.entity.Customer;
import com.codersarts.foodorb.entity.Food;

public interface customerRepo extends JpaRepository<Customer, Integer>{

	Customer findByEmail(String email);
}
