package com.codersarts.foodorb.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codersarts.foodorb.Exception.ResourceNotFoundException;
import com.codersarts.foodorb.UI.orderResponse;
import com.codersarts.foodorb.dao.*;
import com.codersarts.foodorb.entity.Customer;
import com.codersarts.foodorb.entity.orders;

@Service
public class orderServiceImpl implements orderService {

	@Autowired
	private ordersRepo orderrepo;
	
	@Autowired
	private  customerRepo customerrepo;
	
	@Override
	public List<orderResponse> myOrders(String email) {
		
		//Customer customer=this.customerrepo.findById;(id).orElseThrow(()->new ResourceNotFoundException("customer","customerId",id));
		Customer c=this.customerrepo.findByEmail(email);
		List<orders> o=this.orderrepo.findByCustomer(c);
		
		List<orderResponse> response=new ArrayList<>();
		
		for(orders temp:o) {
			response.add(new orderResponse(temp.getOrderTrackingNumber(),temp.getTotalPrice(),temp.getTotalQuantity(),temp.getDateCreated()));
		}
			
		return response;
	}

}
