package com.codersarts.foodorb.services;

import com.codersarts.foodorb.Dto.Purchase;
import com.codersarts.foodorb.UI.purchaseResponse;

public interface checkoutService {

	purchaseResponse placeOrder(Purchase p);
}
