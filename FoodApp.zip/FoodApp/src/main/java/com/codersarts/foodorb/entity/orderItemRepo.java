package com.codersarts.foodorb.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface orderItemRepo extends JpaRepository<orderItem,Integer>{

}
