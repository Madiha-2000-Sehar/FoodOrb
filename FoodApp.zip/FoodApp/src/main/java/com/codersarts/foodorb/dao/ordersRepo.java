package com.codersarts.foodorb.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codersarts.foodorb.entity.Customer;
import com.codersarts.foodorb.entity.Food;
import com.codersarts.foodorb.entity.orders;

public interface ordersRepo  extends JpaRepository<orders, Integer>{

	List<orders> findByCustomer(Customer customer);
}
