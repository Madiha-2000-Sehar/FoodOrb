package com.codersarts.foodorb.dao;

import org.springframework.data.jpa.repository.JpaRepository;


import com.codersarts.foodorb.entity.Food;
import com.codersarts.foodorb.entity.foodCategory;


public interface categoryRepo extends JpaRepository<foodCategory, Long>{

}
