package com.codersarts.foodorb.entity;


import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class orders {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderId;
	
	private String orderTrackingNumber;
	
	private String status;
	
	private int totalPrice;
	
	private int totalQuantity;
	
	
	@CreationTimestamp
	private Date dateCreated;
	
	
	@UpdateTimestamp
	private Date lastUpdated;
	
	@OneToOne
	@JoinColumn(name="shipping_address_id",referencedColumnName="addressId")
	private Address shippingAddress;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="customer_id")
	private Customer customer;
	
	@OneToMany(mappedBy="o")
	private Set<orderItem> item;
	
}
