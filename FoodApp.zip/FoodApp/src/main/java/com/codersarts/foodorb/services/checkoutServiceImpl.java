package com.codersarts.foodorb.services;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codersarts.foodorb.Dto.Purchase;
import com.codersarts.foodorb.UI.purchaseResponse;
import com.codersarts.foodorb.dao.addressRepo;
import com.codersarts.foodorb.dao.customerRepo;
import com.codersarts.foodorb.dao.ordersRepo;
import com.codersarts.foodorb.entity.Address;
import com.codersarts.foodorb.entity.Customer;
import com.codersarts.foodorb.entity.orderItem;
import com.codersarts.foodorb.entity.orderItemRepo;
import com.codersarts.foodorb.entity.orders;

@Service
public class checkoutServiceImpl implements checkoutService {

	@Autowired
	private customerRepo customerrepo;
	
	
	@Autowired
	private addressRepo addressrepo;
	
	@Autowired
	private ordersRepo ordersrepo;
	
	
	@Autowired
	private orderItemRepo orderitemrepo;
	
	@Override
	public purchaseResponse placeOrder(Purchase p) {
		
		boolean customerExists=false;
		
		orders order=p.getOrder();
		
		String trackingNumber=UUID.randomUUID().toString();
		
		order.setOrderTrackingNumber(trackingNumber);
		
		Customer customer=p.getCustomer();
		
		Customer c=this.customerrepo.findByEmail(customer.getEmail());
		
		if(c==null)
			
			this.customerrepo.save(customer);
		else
			customerExists=true;
		
		//System.out.println(customer.getCustomerId()+""+c.getCustomerId());
		
		if(customerExists)
		order.setCustomer(c);
		
		else
			order.setCustomer(customer);
		
		order.setShippingAddress(p.getShippingAddress());
		
		order.setItem(p.getItems());
		
	
		
		Address address=p.getShippingAddress();
		
		
		if(customerExists)
		address.setCustomer(c);
		
		else
			address.setCustomer(customer);
		
		this.addressrepo.save(address);
		
		this.ordersrepo.save(order);
		
		Set<orderItem> items=p.getItems();
		
		for(orderItem i:items) {
			i.setO(order);
			this.orderitemrepo.save(i);
		}
		return new purchaseResponse(order.getOrderTrackingNumber());
		
		
	}

}