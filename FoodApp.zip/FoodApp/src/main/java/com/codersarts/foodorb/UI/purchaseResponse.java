package com.codersarts.foodorb.UI;

import com.codersarts.foodorb.Dto.categoryDto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class purchaseResponse {

	private String orderTrackingNumber;
}
