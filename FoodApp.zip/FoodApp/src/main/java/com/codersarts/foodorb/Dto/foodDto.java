package com.codersarts.foodorb.Dto;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.codersarts.foodorb.entity.foodCategory;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class foodDto {

	
	private Long id;
	
	
	private categoryDto category;
	
	private String name;
	
	private String description;
	
	private double price;
	
	private String priceDesc;
	
	private String imageUrl;
	
	private String restaurantName;

}
