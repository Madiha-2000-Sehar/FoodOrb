package com.codersarts.foodorb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.codersarts.foodorb.Dto.categoryDto;
import com.codersarts.foodorb.Exception.ApiResponse;
import com.codersarts.foodorb.entity.foodCategory;
import com.codersarts.foodorb.services.categoryService;

@RestController
@RequestMapping("/foodorb/category")
@CrossOrigin("*")
public class categoryController {
	
	
	@Autowired
	private categoryService cService;
	
	@PostMapping("/add-category")
	public ResponseEntity<ApiResponse> addCategory(@RequestBody categoryDto dto){
		
		boolean status=this.cService.addCategory(dto);
		
		if(status)
			return new ResponseEntity(new ApiResponse("Category Added!",true), HttpStatus.CREATED);
		else
		return new ResponseEntity(new ApiResponse("Error Occured!!",false),HttpStatus.BAD_REQUEST);
		
	}
	
	@GetMapping("/")
	public ResponseEntity<List<categoryDto>> getAllCategories(){
		List<categoryDto> dtos=this.cService.getAllCategories();
		return ResponseEntity.ok(dtos) ;
		
	}

}
