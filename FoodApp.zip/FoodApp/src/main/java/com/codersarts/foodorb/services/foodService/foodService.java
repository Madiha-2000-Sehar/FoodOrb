package com.codersarts.foodorb.services.foodService;

import java.util.List;

import com.codersarts.foodorb.Dto.categoryDto;
import com.codersarts.foodorb.Dto.foodDto;

public interface foodService {

	boolean addFood(foodDto dto,Long id);
	List<foodDto> getAllFoods(Integer pageNumber,Integer pageSize);
	List<foodDto> getFoodByCategory(Long id,Integer pageNumber,Integer pageSize);
	List<foodDto> search(String keyword);
	foodDto getFoodById(Long id);
}
