package com.codersarts.foodorb.services;

import java.util.List;

import com.codersarts.foodorb.Dto.categoryDto;

public interface categoryService {

	boolean addCategory(categoryDto dto);
	List<categoryDto> getAllCategories();
	
}
