package com.codersarts.foodorb.UI;

import java.util.Date;
import java.util.Set;

import com.codersarts.foodorb.entity.Address;
import com.codersarts.foodorb.entity.Customer;
import com.codersarts.foodorb.entity.orderItem;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class orderResponse {
	
	private String orderTrackingNumber;

	private int totalPrice;
	
	private int totalQuantity;
	
	private Date dateCreated;
}
