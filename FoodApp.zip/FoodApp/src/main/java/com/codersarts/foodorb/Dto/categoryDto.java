package com.codersarts.foodorb.Dto;

import java.util.Set;

import com.codersarts.foodorb.entity.Food;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class categoryDto {

	private Long id;
	private String categoryName;
}
